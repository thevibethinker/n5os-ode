# N5 Command Authoring Setup - Executable Steps

**State Header** (Do not edit manually—Zo updates this)  
- **Step 0: Unpacked** - Not started.  
- **Step 1: Preflight** - Pending.  
- **Step 2: Structure Creation** - Pending.  
- **Step 3: Foundational Files** - Pending.  
- **Step 4: Verification** - Pending.  
- **Completed**: No (Timestamp: N/A).  
- **Lock**: Unlocked (Run next step to proceed).  

---

### Step 1: Preflight Check and Confirmation
Paste this into Zo chat to begin. Zo will:  
- Scan workspace for conflicts.  
- List planned changes.  
- Require your explicit confirmation (e.g., reply "Confirm" to proceed).  
- Update state to "Step 1: Completed" if successful.

```bash
# Preflight: Check for existing N5 structure
grep_search query="N5" location="USER" search_kind="filename"

# If N5 exists, read summary; else note clean setup
read_file target_file="/home/workspace/N5.md" text_read_entire_file=true  # Assuming N5.md as entrypoint if present

# Planned changes (output to chat for review):
# - Create ./N5/ if missing.
# - Create ./N5/schemas/ if missing.
# - Create/edit ./N5/commands.md with template.
# - Create/edit ./N5/workflows.md with example.
# No deletions or overwrites unless conflicting (will prompt).

# Zo: Ask user "Review planned changes. Reply 'Confirm' to proceed, or 'Abort' to stop."
# If confirmed, proceed to next steps; else halt.
# Update this file's state header: Set Step 1 to "Completed" via edit_file_llm.
```

---

### Step 2: Create Directory Structure
(Execute after Step 1 completes—state lock enforces order.) Zo creates folders.

```bash
# Create root N5 if missing
run_bash_command cmd="mkdir -p /home/workspace/N5"

# Create schemas subdir
run_bash_command cmd="mkdir -p /home/workspace/N5/schemas"

# Update state: Set Step 2 to "Completed"
# Zo: Use edit_file_llm to update the state header in this file.
```

---

### Step 3: Populate Foundational Files
Zo creates/edits core files with generalized templates.

```bash
# Create commands.md with generalized template
create_or_rewrite_file target_file="/home/workspace/N5/commands.md" content="# Command Catalog\n\n## Generalized Command Authoring\n- Commands are parameterized prompts or tool sequences.\n- Example: 'search_web' - Params: query (str). Action: Call web_search.\n\nAdd your commands here."

# Create workflows.md with systematization example
create_or_rewrite_file target_file="/home/workspace/N5/workflows.md" content="# Workflow Systematization\n\n## Example Workflow: Research Topic\n1. Command: search_web(query='topic')\n2. Command: deep_research(instructions='Synthesize results')\n\nChain commands for repeatable processes."

# Create basic schema template in schemas/
create_or_rewrite_file target_file="/home/workspace/N5/schemas/basic.json" content="{\"type\": \"object\", \"properties\": {\"query\": {\"type\": \"string\"}}, \"required\": [\"query\"]}"

# Update state: Set Step 3 to "Completed"
```

---

### Step 4: Verify and Finalize
Zo verifies setup and marks complete.

```bash
# Verify files exist
grep_search query="commands.md|workflows.md|basic.json" location="USER" include_pattern="N5/**" search_kind="filename"

# If all present, output: "Setup complete. Test by invoking a command in chat."
# Update state: Set Step 4 to "Completed", Completed to "Yes (Timestamp: $(date))", Lock to "Locked".
```

**Uninstall/Rollback Guide**  
- Delete via bash: `rm -rf /home/workspace/N5` (backs up first if desired).  
- Or ask Zo: "Remove N5 command authoring setup."