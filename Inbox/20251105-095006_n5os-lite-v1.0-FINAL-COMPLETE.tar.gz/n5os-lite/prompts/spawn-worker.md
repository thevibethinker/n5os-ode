---
tool: true
description: Spawn parallel AI worker for independent task execution
tags: [orchestration, parallel, workers, advanced]
version: 1.0
created: 2025-11-03
---

# Spawn Worker

**Create parallel AI worker for independent task execution**

Part of the Build Orchestrator system. Enables true parallel work across multiple AI conversations.

---

## When to Use

**Use Spawn Worker when:**
- Task is independent and can run in parallel
- Need fresh context (avoiding conversation pollution)
- Want specialized focus without switching modes
- Building complex systems with discrete components

**Don't use when:**
- Task needs continuous back-and-forth
- Requires shared state updates
- Sequential dependency on current work
- Simple task better done inline

---

## How It Works

### Concept

```
Parent Conversation (Orchestrator)
├── Spawns → Worker 1 (new conversation)
├── Spawns → Worker 2 (new conversation)  
└── Collects results from workers
```

Each worker:
- Gets full context from parent
- Runs independently
- Delivers results back to parent

---

## Instructions

### 1. Prepare Worker Brief

Create worker brief following `file 'examples/worker_brief_template.md'`:

```markdown
# WORKER_1: Implement Authentication

## Mission
Build OAuth2 authentication module with Google provider.

## Context
[Provide necessary background]

## Requirements
- Feature 1
- Feature 2

## Deliverables
- auth.py module
- tests/test_auth.py
- docs/auth.md

## Success Criteria
- [ ] All tests pass
- [ ] Documentation complete
```

### 2. Spawn Worker

**Tell your AI:**
```
"Create a new conversation for this worker brief.
Title: WORKER_1: Implement Authentication
Context: [paste worker brief]"
```

### 3. Monitor Progress

Worker updates parent via:
- Artifact delivery to shared location
- Status updates in worker conversation
- Final delivery with completion report

### 4. Integrate Results

Parent orchestrator:
- Collects worker outputs
- Validates against requirements
- Integrates into main build

---

## Worker Brief Structure

**Required Sections:**
1. **Mission** - One sentence goal
2. **Context** - Background information
3. **Requirements** - Specific needs
4. **Deliverables** - What to produce
5. **Success Criteria** - How to validate

**Optional Sections:**
- Dependencies
- Constraints
- Timeline
- Integration notes

---

## Best Practices

### Clear Objectives
```
✅ Good: "Implement OAuth2 with Google provider, return auth tokens"
❌ Bad: "Do authentication stuff"
```

### Explicit Deliverables
```
✅ Good: "Deliver: auth.py, test_auth.py, README.md"
❌ Bad: "Make it work"
```

### Success Criteria
```
✅ Good: "All tests pass, docs complete, follows P15"
❌ Bad: "Looks good"
```

---

## Example Worker Brief

```markdown
# WORKER_2: Design Database Schema

## Mission
Design and document user authentication database schema.

## Context
Building user auth system. Need to store:
- User credentials
- Session tokens
- OAuth provider info

## Requirements
- Support email/password + OAuth
- Session management
- Token refresh capability

## Deliverables
1. schema.sql - Database DDL
2. models.py - ORM models
3. migrations/ - Migration scripts
4. docs/database.md - Schema documentation

## Success Criteria
- [ ] Schema supports all auth methods
- [ ] Migration scripts tested
- [ ] Documentation includes ER diagram
- [ ] Follows naming conventions (P13)

## Timeline
Estimated: 45 minutes

## Dependencies
None - can start immediately

## Integration
Deliver files to: /build/database/
Parent will integrate with auth module from Worker 1
```

---

## Advanced: Multiple Workers

For complex builds:

```
Orchestrator
├── Worker 1: Frontend UI
├── Worker 2: Backend API
├── Worker 3: Database Schema
├── Worker 4: Testing Suite
└── Worker 5: Documentation
```

**Orchestrator responsibilities:**
- Define worker boundaries
- Manage dependencies
- Collect and integrate results
- Validate complete system

---

## Related

- System: `build_orchestrator.md` - Full orchestration pattern
- Principles: P36 (Orchestration Pattern)
- Examples: `worker_brief_template.md`
- Prompt: `review-work.md` - Validate worker output

---

*Parallel work = faster builds. Use workers for independent tasks.*
