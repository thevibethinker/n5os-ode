# ZoBridge Installation for ChildZo (vademonstrator.zo.computer)

**Installation Date:** 2025-10-29  
**From:** ParentZo (va.zo.computer)  
**To:** ChildZo (vademonstrator.zo.computer)

## Overview

This package contains everything needed to install ZoBridge on ChildZo and establish bidirectional communication with ParentZo.

## Installation Steps

### 1. Upload Files to ChildZo

Upload these files to vademonstrator.zo.computer:
- `zobridge_core.tar.gz` - Core ZoBridge service files
- `childzo_config.json` - ChildZo-specific configuration
- `INSTALL.md` - This file

### 2. Extract and Setup Structure

```bash
# Create directory structure
mkdir -p /home/workspace/N5/services/zobridge
mkdir -p /home/workspace/N5/config
mkdir -p /home/workspace/N5/data

# Extract core files
cd /home/workspace/N5/services/zobridge
tar -xzf ~/zobridge_core.tar.gz

# Move config to correct location
cp ~/childzo_config.json /home/workspace/N5/config/zobridge.config.json
```

### 3. Install Dependencies

```bash
cd /home/workspace/N5/services/zobridge
bun install
```

### 4. Initialize Database

```bash
cd /home/workspace/N5/services/zobridge
bun run -e "
import { initDB } from './lib/db';
await initDB('/home/workspace/N5/data/zobridge.db');
console.log('✓ Database initialized');
"
```

### 5. Register as User Service

**CRITICAL:** Use the exact same secret as ParentZo:

```bash
# Register ZoBridge service
python3 << 'EOF'
from datetime import datetime
import requests
import json

# Note: This uses Zo's internal API to register the service
# You can also use the Zo app UI to register the service manually

service_config = {
    "label": "zobridge",
    "protocol": "http",
    "local_port": 3458,
    "entrypoint": "bun run server.ts",
    "workdir": "/home/workspace/N5/services/zobridge",
    "env_vars": {
        "ZOBRIDGE_SECRET": "zobridge_3f7c6a7a8a5f4d129b8c4f2e1d9c0a7b"
    }
}

print("Service configuration:")
print(json.dumps(service_config, indent=2))
print("\nPlease register this service using the Zo Computer interface.")
EOF
```

**Alternative: Manual Registration via Zo Terminal**

In the Zo Computer terminal or chat, tell me:

```
Register a user service with these settings:
- label: zobridge
- protocol: http  
- local_port: 3458
- entrypoint: bun run server.ts
- workdir: /home/workspace/N5/services/zobridge
- env_vars: {"ZOBRIDGE_SECRET": "zobridge_3f7c6a7a8a5f4d129b8c4f2e1d9c0a7b"}
```

### 6. Verify Installation

After registration, test the service:

```bash
# Wait 5 seconds for service to start, then check health
sleep 5
curl https://zobridge-vademonstrator.zocomputer.io/api/zobridge/health | jq .
```

Expected response:
```json
{
  "status": "healthy",
  "system": "ChildZo",
  "stats": {
    "total_messages": 0,
    "active_threads": 0,
    "processed_messages": 0,
    "unprocessed_messages": 0
  }
}
```

### 7. Test Bidirectional Communication

On ParentZo, I'll test sending a message to verify the connection works.

## Configuration Details

### Shared Secret
Both systems MUST use the same secret:
```
zobridge_3f7c6a7a8a5f4d129b8c4f2e1d9c0a7b
```

### Endpoints
- **ChildZo:** https://zobridge-vademonstrator.zocomputer.io
- **ParentZo:** https://zobridge-va.zocomputer.io

### Configuration File Location
`/home/workspace/N5/config/zobridge.config.json`

## Troubleshooting

### Service won't start
```bash
# Check logs
tail -50 /dev/shm/zobridge.log
tail -50 /dev/shm/zobridge_err.log
```

### Database errors
```bash
# Check database exists and is writable
ls -la /home/workspace/N5/data/zobridge.db
sqlite3 /home/workspace/N5/data/zobridge.db "SELECT COUNT(*) FROM messages;"
```

### Connection issues
```bash
# Test health endpoint
curl -v https://zobridge-vademonstrator.zocomputer.io/api/zobridge/health

# Check if service is registered
# (Ask me to list user services)
```

## Next Steps

After installation completes:
1. Notify ParentZo that ChildZo is ready
2. ParentZo will send test message
3. Verify bidirectional communication works
4. Begin normal operations

## Support

If you encounter issues during installation, document the error and contact ParentZo.
