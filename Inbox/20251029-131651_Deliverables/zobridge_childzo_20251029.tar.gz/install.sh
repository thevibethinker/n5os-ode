#!/bin/bash
# ZoBridge Installation Script for ChildZo
# Run this on vademonstrator.zo.computer

set -e

echo "🌉 ZoBridge Installation for ChildZo"
echo "====================================="
echo ""

# Create directory structure
echo "Creating directory structure..."
mkdir -p /home/workspace/N5/services/zobridge
mkdir -p /home/workspace/N5/config
mkdir -p /home/workspace/N5/data

# Extract core files
echo "Extracting ZoBridge core files..."
cd /home/workspace/N5/services/zobridge
tar -xzf ~/zobridge_core.tar.gz

# Copy config
echo "Installing configuration..."
cp ~/childzo_config.json /home/workspace/N5/config/zobridge.config.json

# Install dependencies
echo "Installing dependencies..."
bun install

# Initialize database
echo "Initializing database..."
sqlite3 /home/workspace/N5/data/zobridge.db << 'SQL'
CREATE TABLE IF NOT EXISTS messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  message_id TEXT UNIQUE,
  direction TEXT CHECK(direction IN ('in','out')) NOT NULL,
  mfrom TEXT,
  mto TEXT,
  mtype TEXT,
  status TEXT,
  payload TEXT NOT NULL,
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_messages_out_queued_to 
  ON messages(status, mto, created_at);

CREATE TABLE IF NOT EXISTS checkpoints (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  checkpoint_at TEXT NOT NULL,
  message_count INTEGER NOT NULL,
  last_message_id TEXT
);
SQL

echo ""
echo "✓ Installation complete!"
echo ""
echo "Next step: Register the service"
echo "================================"
echo ""
echo "Run this command in Zo Computer chat:"
echo ""
echo "Register a user service with these settings:"
echo "  label: zobridge"
echo "  protocol: http"
echo "  local_port: 3458"
echo "  entrypoint: bun run server.ts"
echo "  workdir: /home/workspace/N5/services/zobridge"
echo '  env_vars: {"ZOBRIDGE_SECRET": "zobridge_3f7c6a7a8a5f4d129b8c4f2e1d9c0a7b"}'
echo ""
