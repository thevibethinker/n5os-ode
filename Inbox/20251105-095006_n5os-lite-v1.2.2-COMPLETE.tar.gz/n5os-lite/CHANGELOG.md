# N5OS Lite Changelog

All notable changes to N5OS Lite.

---

## [1.2.2] - 2025-11-03

### 🔧 Fixed (Critical)
- Schema-script field mismatch (name/description vs title/body)
- Missing dependencies (executable_manager.py, direct_ingestion_mechanism.py)
- Directory structure confusion (.n5os vs Lists vs workspace)
- ConversationDB integration added

### ➕ Added
- conversation_registry.py - Full conversation tracking
- executable_manager.py - Command/tool registry stub
- direct_ingestion_mechanism.py - Knowledge ingestion stub
- QUICKREF.md - Quick reference card
- TROUBLESHOOTING.md - Comprehensive troubleshooting
- ASSUMPTIONS.md - All assumptions documented
- CRITICAL_FIXES_v1.2.2.md - What was broken and fixed

### 📝 Changed
- Updated all scripts to use correct schema field names
- Standardized directory structure recommendations
- Improved error messages in scripts

### 🎯 Quality
- P15 compliance: Honest progress reporting
- P21 compliance: All assumptions documented
- P23 compliance: Trap doors identified
- P28 compliance: Plan-code alignment verified

---

## [1.2.1] - 2025-11-03

### 🔧 Fixed
- Missing n5_safety.py module (blocked 8 of 14 scripts)

### ➕ Added
- n5_safety.py - Safety checking and mock detection

---

## [1.2.0] - 2025-11-03

### ➕ Added
- 14 Python scripts for all prompts
- Working backends for list management
- Working backends for knowledge management  
- Working backends for conversation management
- Script execution layer

### 📝 Changed
- All prompts now functional (not just documented)

---

## [1.1.0] - 2025-11-03

### ➕ Added
- incantum-quickref.md - Natural language triggers
- spawn-worker.md - Parallel worker spawning
- docgen.md - Documentation generation
- generate-docs.md - Doc automation
- service_recommendations.md - Optional services
- orchestrator examples
- Config templates (default.yaml, persona_config.yaml, list_schemas.yaml)
- Scheduled task examples

### 📝 Documentation
- 4 new prompts
- 3 config templates  
- 2 service guides
- 1 orchestrator example

---

## [1.0.0] - 2025-11-03

### 🎉 Initial Release

#### Core Components
- 8 Personas (Operator, Builder, Strategist, Architect, Writer, Teacher, Debugger, Researcher)
- 19 Principles (P1-P37 selection)
- 10 Prompts (Planning, Thinking, Close, Export, Add-to-list, Query, Review, Create, Generate-docs, Knowledge-ingest)
- 15 Rules (Recommended behavioral rules)

#### Documentation
- README.md
- QUICKSTART.md  
- INSTALLATION.md
- ARCHITECTURE.md
- CONTRIBUTING.md

#### System Components
- directory_structure.md
- filesystem_standard.md
- list_maintenance_protocol.md
- protection_system.md
- state_management.md
- build_orchestrator.md
- preferences_system.md
- naming_conventions.md

#### Scripts & Tools
- file_guard.py
- validate_list.py
- system_health_check.py
- onboarding_wizard.py
- bootstrap.sh
- setup.sh

#### Schemas
- list_entry.schema.json
- persona.schema.yaml
- prompt.schema.yaml

#### Examples
- sample_tools_list.jsonl
- worker_brief_template.md
- scheduled_tasks.md

---

## Version History Summary

| Version | Date | Key Changes | Size |
|---------|------|-------------|------|
| 1.2.2 | 2025-11-03 | Critical fixes, ConversationDB | 152KB |
| 1.2.1 | 2025-11-03 | n5_safety.py hotfix | 146KB |
| 1.2.0 | 2025-11-03 | All scripts added | 144KB |
| 1.1.0 | 2025-11-03 | Config + services | 107KB |
| 1.0.0 | 2025-11-03 | Initial release | 94KB |

---

## Upgrade Path

### 1.0 → 1.2.2
Apply delta package: `n5os-lite-v1.0-to-v1.2.2-DELTA.tar.gz`

### 1.2.1 → 1.2.2
Apply delta package: `n5os-lite-v1.2.1-to-v1.2.2-DELTA.tar.gz`

---

## Breaking Changes

### 1.2.2
- Schema field names changed (title→name, body→description, open→active)
- Directory structure standardized (.n5os/ required)

### 1.2.0
- Scripts now required for prompts to function
- Python 3.10+ required

---

## Deprecations

None yet. All v1.0 features still work.

---

## Roadmap

### v1.3.0 (Future)
- Web UI for list management
- Real-time collaboration support
- Cloud storage integration
- Automated backups
- Plugin system

### v2.0.0 (Future)
- Distributed architecture
- Multi-user support
- REST API
- Mobile app

---

**For detailed changes, see commit history and CRITICAL_FIXES documents.**

*Changelog | Maintained by N5OS Lite Core Team*
