#!/usr/bin/env python3
"""
Demo: Priority 2 API Integration
Shows what will happen when Howie adds V-OS tags
"""

import sys
sys.path.insert(0, '/home/workspace/N5/scripts')

from meeting_api_integrator import MeetingAPIIntegrator
from meeting_processor import MeetingProcessor


class MockCalendarAPI:
    """Mock Google Calendar API with tagged event"""
    
    def __call__(self, tool_name, configured_props):
        # Simulate what Howie's tagged event will look like
        return {
            'items': [
                {
                    'id': 'real_event_abc123',
                    'summary': 'Series A Discussion - Jane Smith (Acme Ventures)',
                    'description': '''[LD-INV] [D5+] *

Purpose: Discuss Series A funding timeline and terms

Context: Jane replied to Mike's intro email, expressed strong interest in Careerspan's ed-tech traction and mission-driven approach, wants to discuss funding terms and timeline for potential Series A investment.

---
Please send pitch deck in advance to vrijen@mycareerspan.com.

Meeting Link: https://zoom.us/j/12345''',
                    'start': {
                        'dateTime': '2025-10-15T14:00:00-04:00'
                    },
                    'attendees': [
                        {
                            'email': 'vrijen@mycareerspan.com',
                            'displayName': 'Vrijen Attawar',
                            'self': True
                        },
                        {
                            'email': 'jane@acmeventures.com',
                            'displayName': 'Jane Smith'
                        }
                    ]
                }
            ]
        }


class MockGmailAPI:
    """Mock Gmail API with email context"""
    
    def __call__(self, tool_name, configured_props):
        return {
            'messages': [
                {
                    'id': 'msg123',
                    'internalDate': '1728518400000',  # Oct 10, 2025
                    'payload': {
                        'headers': [
                            {'name': 'Subject', 'value': 'Introduction - Vrijen Attawar (Careerspan)'}
                        ]
                    },
                    'snippet': 'Jane replied to intro, expressed interest in ed-tech space and mission-driven founders...'
                },
                {
                    'id': 'msg124',
                    'internalDate': '1728604800000',  # Oct 11, 2025
                    'payload': {
                        'headers': [
                            {'name': 'Subject', 'value': 'Re: Introduction - Pitch Deck Request'}
                        ]
                    },
                    'snippet': 'Jane requested pitch deck and shared investment thesis on education technology...'
                }
            ]
        }


def demo():
    """
    Demonstrate what will happen when Howie adds V-OS tags
    """
    print("=" * 70)
    print("DEMO: Priority 2 API Integration")
    print("Simulating what will happen when Howie adds V-OS tags to calendar")
    print("=" * 70)
    print()
    
    # Create mock APIs
    mock_calendar = MockCalendarAPI()
    mock_gmail = MockGmailAPI()
    
    # Create API integrator with mocks
    api = MeetingAPIIntegrator(
        calendar_tool=mock_calendar,
        gmail_tool=mock_gmail
    )
    
    # Create processor
    processor = MeetingProcessor(api)
    
    # Process meetings
    print("🚀 Starting meeting processor...\n")
    results = processor.process_upcoming_meetings(days_ahead=7)
    
    # Show what was created
    print()
    print("=" * 70)
    print("WHAT HAPPENED:")
    print("=" * 70)
    print()
    print("✅ Calendar API fetched events with V-OS tags")
    print("✅ Gmail API searched for attendee email context")
    print("✅ Stakeholder profile created with:")
    print("   - Name: Jane Smith")
    print("   - Organization: Acme Ventures")
    print("   - Type: Investor")
    print("   - Email history: 2 threads")
    print("   - Meeting details with tags")
    print("✅ Event marked as processed in state file")
    print()
    print("📊 RESULTS:")
    print(f"   Total events: {results['total_events']}")
    print(f"   New processed: {results['new_events']}")
    print(f"   New profiles: {results['new_profiles']}")
    print()
    print("=" * 70)
    print("NEXT: Once real tags added, this will run automatically every 15 min")
    print("=" * 70)


if __name__ == "__main__":
    demo()
