## 2026-02-22 04:15 UTC - Layer 2 Healthcheck

**Status: DEGRADED**

| Check | Result |
|-------|--------|
| office.db readable | OK |
| webhook /api/zoffice/webhooks/vapi | OK |
| webhook /api/zoffice/webhooks/github | OK |
| webhook /api/zoffice/webhooks/stripe | OK |
| office.yaml | MISSING |
| integration.yaml | MISSING |
| routing.yaml | MISSING |
| security.yaml | MISSING |

**Action Required**: Core config files not found at `/home/workspace/Zoffice/`. Verify Zoffice deployment or restore from backup.

---
