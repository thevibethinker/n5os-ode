# Careerspan Organization Reference

**Version:** 1.0  
**Last Updated:** 2025-10-10  
**Purpose:** Canonical information about Careerspan organization, identity, and aliases

---

## Organization Identity and Aliases

### Company Name
- **Current:** Careerspan
- **Legacy:** Apply AI
- **Treatment:** Treat "Careerspan" and "Apply AI" as identical entities in all contexts

### Email Domains
- **Primary:** mycareerspan.com
- **Legacy:** theapply.ai
- **Classification:** Both domains are internal and equivalent
- **Employee Canonicalization:** Any current employee with a theapply.ai address is a Careerspan employee

### Downstream Effects
The following systems must treat these domains as one organization:
- Scheduling
- Digest generation
- Contact classification
- CRM mapping

---

## Quick Reference

**When processing emails/contacts:**
- `@mycareerspan.com` = Internal
- `@theapply.ai` = Internal (legacy)
- Treat both as the same organization in all routing and classification

**When writing about the company:**
- Use "Careerspan" (not "CareerSpan")
- Legacy references to "Apply AI" refer to the same entity

---

## Team Members

### Logan
- **Role:** Co-founder, Chief Operating Officer (COO)
- **Responsibilities:** Marketing and community engagement
- **Coordination tag:** [LOG] in N5OS system

### Ilse
- **Role:** Chief Technology Officer (CTO), Head of AI Engineering
- **Responsibilities:** Technology and AI engineering
- **Coordination tag:** [ILS] in N5OS system

### Vrijen (V)
- **Role:** Founder
- **Responsibilities:** Hiring, sales, and investment

---

## Related Resources

- Company overview → `file 'Knowledge/stable/company/overview.md'`
- Company strategy → `file 'Knowledge/stable/company/strategy.md'`
- Company timeline → `file 'Knowledge/stable/careerspan-timeline.md'`
- Glossary → `file 'Knowledge/stable/glossary.md'`
