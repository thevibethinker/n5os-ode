---
date: "2025-09-20T22:24:55Z"
last-tested: "2025-09-20T22:24:55Z"
generated_date: "2025-09-20T22:24:55Z"
checksum: f0591e9c123fab37e3e43e291c971f39
tags:
category: unknown
priority: medium
related_files:
anchors: [object Object]
---
# `digest-runs`\n\nVersion: 0.1.0\n\nSummary: Generate digest reports from run records for analysis and monitoring.\n\nWorkflow: ops\n\nTags: observability, monitoring, digest\n\n## Inputs\n- command : string — Specific command to analyze\n- format : enum [default: markdown] — Output format\n- since : date — Start date (YYYY-MM-DD)\n- until : date — End date (YYYY-MM-DD)\n- limit : number — Maximum runs to analyze\n\n## Outputs\n- report : file (markdown) — Digest report file\n\n## Side Effects\n- writes:file\n\n## Examples\n- N5: run digest-runs\n- N5: run digest-runs command=docgen --format=summary\n- N5: run digest-runs --since=2025-09-01 --until=2025-09-17\n\n## Related Components\n\n**Related Commands**: [`docgen`](../commands/docgen.md), [`index-update`](../commands/index-update.md), [`index-rebuild`](../commands/index-rebuild.md)\n\n**Examples**: See [Examples Library](../examples/) for usage patterns\n\n