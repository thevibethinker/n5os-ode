#!/usr/bin/env python3
"""
N5 Conversation End-Step
Formal conversation close with AAR generation, file organization and cleanup

This is the "end step" (like Magic: The Gathering) where all conversation
effects are resolved - AAR generated, files reviewed, organized, and cleaned up.
"""

import os
import sys
import json
import shutil
import logging
import subprocess
from pathlib import Path
from datetime import datetime
from collections import defaultdict

# Import timeline automation
sys.path.insert(0, str(Path(__file__).parent))
try:
    from timeline_automation_module import add_timeline_entry_from_workspace
    TIMELINE_AUTOMATION_AVAILABLE = True
except ImportError:
    TIMELINE_AUTOMATION_AVAILABLE = False

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Paths
WORKSPACE = Path("/home/workspace")

# Detect conversation workspace from environment or by finding the workspace we're in
CONVERSATION_WS_ENV = os.getenv("CONVERSATION_WORKSPACE")
if CONVERSATION_WS_ENV:
    CONVERSATION_WS = Path(CONVERSATION_WS_ENV)
else:
    # Try to detect from common patterns
    workspaces_dir = Path("/home/.z/workspaces")
    if workspaces_dir.exists():
        # Find most recently modified workspace
        workspaces = [d for d in workspaces_dir.iterdir() if d.is_dir() and d.name.startswith("con_")]
        if workspaces:
            CONVERSATION_WS = max(workspaces, key=lambda d: d.stat().st_mtime)
        else:
            CONVERSATION_WS = None
    else:
        CONVERSATION_WS = None

DOCUMENT_INBOX = WORKSPACE / "Document Inbox/Temporary"
LOG_FILE = WORKSPACE / "N5/runtime/conversation_ends.log"


def log_action(message):
    """Log to file and print"""
    timestamp = datetime.now().isoformat()
    log_line = f"[{timestamp}] {message}"
    print(message)
    
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, 'a') as f:
        f.write(log_line + '\n')


def classify_file(filepath):
    """
    Classify file by type and content to determine destination
    
    Returns: (destination, action, reason)
        destination: Path or None
        action: "move" | "delete" | "ask"
        reason: Explanation
    """
    name = filepath.name.lower()
    ext = filepath.suffix.lower()
    
    # Classification rules
    
    # Images
    if ext in ['.png', '.jpg', '.jpeg', '.gif', '.svg', '.webp']:
        if any(x in name for x in ['temp', 'test', 'chart', 'viz']):
            return (None, "delete", "Temporary visualization")
        else:
            dest = WORKSPACE / "Images" / filepath.name
            return (dest, "move", "Generated/downloaded image")
    
    # Meeting transcripts
    if any(x in name for x in ['transcript', 'meeting']):
        dest = DOCUMENT_INBOX.parent / "Company/meetings" / filepath.name
        return (dest, "move", "Meeting transcript for processing")
    
    # Analysis/reports
    if any(x in name for x in ['analysis', 'report', 'summary']):
        dest = WORKSPACE / "Documents" / filepath.name
        return (dest, "move", "Analysis/report document")
    
    # Scripts
    if ext in ['.py', '.sh', '.js']:
        if any(x in name for x in ['temp', 'test', 'tmp']):
            return (None, "delete", "Temporary script")
        else:
            return (None, "ask", "Script - determine if permanent")
    
    # Data exports
    if ext in ['.csv', '.json', '.jsonl']:
        if any(x in name for x in ['temp', 'test', 'intermediate']):
            return (None, "delete", "Temporary data file")
        else:
            dest = WORKSPACE / "Exports" / filepath.name
            return (dest, "move", "Data export")
    
    # Documents
    if ext in ['.md', '.txt', '.pdf', '.docx']:
        if any(x in name for x in ['temp', 'test', 'draft', 'scratch']):
            return (None, "delete", "Temporary document")
        else:
            # Default to Document Inbox for review
            dest = DOCUMENT_INBOX / filepath.name
            return (dest, "move", "Document for review")
    
    # Default: Ask user
    return (None, "ask", "Unknown file type")


def inventory_workspace():
    """
    Inventory all files in conversation workspace
    
    Returns: dict of {category: [files]}
    """
    if not CONVERSATION_WS.exists():
        print(f"⚠️  Conversation workspace not found: {CONVERSATION_WS}")
        print("   Using current directory for demonstration")
        return {}
    
    files_by_category = defaultdict(list)
    
    for filepath in CONVERSATION_WS.rglob("*"):
        if filepath.is_file():
            dest, action, reason = classify_file(filepath)
            category = f"{action.upper()}"
            files_by_category[category].append({
                "file": filepath,
                "dest": dest,
                "reason": reason
            })
    
    return files_by_category


def propose_organization(files_by_category):
    """
    Propose file organization to user
    
    Returns formatted proposal
    """
    proposal = []
    proposal.append("\n" + "="*70)
    proposal.append("CONVERSATION END-STEP: File Organization")
    proposal.append("="*70)
    
    total_files = sum(len(files) for files in files_by_category.values())
    proposal.append(f"\nFiles created this conversation: {total_files}\n")
    
    # Group by action
    for action in ["MOVE", "DELETE", "ASK"]:
        files = files_by_category.get(action, [])
        if not files:
            continue
        
        if action == "MOVE":
            proposal.append(f"\n📁 FILES TO MOVE ({len(files)} files)")
            proposal.append("-" * 70)
            
            # Group by destination
            by_dest = defaultdict(list)
            for item in files:
                dest_dir = item['dest'].parent if item['dest'] else "Unknown"
                by_dest[dest_dir].append(item)
            
            for dest_dir, items in sorted(by_dest.items()):
                proposal.append(f"\n  → {dest_dir}/")
                for item in sorted(items, key=lambda x: x['file'].name):
                    proposal.append(f"     ✓ {item['file'].name}")
                    proposal.append(f"        ({item['reason']})")
        
        elif action == "DELETE":
            proposal.append(f"\n🗑️  FILES TO DELETE ({len(files)} files)")
            proposal.append("-" * 70)
            for item in sorted(files, key=lambda x: x['file'].name):
                proposal.append(f"  ✗ {item['file'].name}")
                proposal.append(f"     ({item['reason']})")
        
        elif action == "ASK":
            proposal.append(f"\n❓ FILES NEEDING DECISION ({len(files)} files)")
            proposal.append("-" * 70)
            for item in sorted(files, key=lambda x: x['file'].name):
                proposal.append(f"  ? {item['file'].name}")
                proposal.append(f"     ({item['reason']})")
    
    # Summary
    move_count = len(files_by_category.get("MOVE", []))
    delete_count = len(files_by_category.get("DELETE", []))
    ask_count = len(files_by_category.get("ASK", []))
    
    proposal.append("\n" + "="*70)
    proposal.append(f"SUMMARY: {move_count} move, {delete_count} delete, {ask_count} need decision")
    proposal.append("="*70)
    proposal.append("\nProceed with moves and deletions? (Y/n)")
    
    return "\n".join(proposal)


def execute_organization(files_by_category, confirmed=True):
    """
    Execute file moves and deletions
    """
    if not confirmed:
        print("❌ Organization cancelled by user")
        return
    
    print("\n" + "="*70)
    print("EXECUTING FILE ORGANIZATION")
    print("="*70 + "\n")
    
    moved_count = 0
    deleted_count = 0
    errors = []
    
    # Execute moves
    for item in files_by_category.get("MOVE", []):
        try:
            # Create destination directory
            item['dest'].parent.mkdir(parents=True, exist_ok=True)
            
            # Move file
            shutil.move(str(item['file']), str(item['dest']))
            
            moved_count += 1
            log_action(f"Moved: {item['file'].name} → {item['dest'].relative_to(WORKSPACE)}")
            
        except Exception as e:
            errors.append(f"{item['file'].name}: {e}")
    
    # Execute deletions
    for item in files_by_category.get("DELETE", []):
        try:
            item['file'].unlink()
            deleted_count += 1
            log_action(f"Deleted: {item['file'].name} (temporary)")
        except Exception as e:
            errors.append(f"{item['file'].name}: {e}")
    
    # Report
    print(f"✓ Moved {moved_count} files")
    print(f"✗ Deleted {deleted_count} files")
    
    if errors:
        print(f"\n⚠️  {len(errors)} errors:")
        for err in errors[:10]:
            print(f"  - {err}")
    
    # Handle ASK files
    ask_files = files_by_category.get("ASK", [])
    if ask_files:
        print(f"\n❓ {len(ask_files)} files need manual decision")
        print("   Keeping in conversation workspace for now")
    
    return {
        "moved": moved_count,
        "deleted": deleted_count,
        "errors": len(errors),
        "pending": len(ask_files)
    }


def cleanup_workspace_root():
    """
    Clean up workspace root files (conversation artifacts).
    This is Phase 2 of conversation-end cleanup.
    """
    print("\n" + "="*70)
    print("PHASE 2: WORKSPACE ROOT CLEANUP")
    print("="*70)
    print("\nScanning for conversation artifacts in workspace root...\n")
    
    cleanup_script = WORKSPACE / "N5/scripts/n5_workspace_root_cleanup.py"
    
    if not cleanup_script.exists():
        print("⚠️  Cleanup script not found, skipping workspace root cleanup")
        return
    
    try:
        # Run cleanup with auto-execute
        result = subprocess.run(
            [sys.executable, str(cleanup_script), "--execute"],
            capture_output=True,
            text=True,
            check=False
        )
        
        # Print output
        print(result.stdout)
        
        if result.returncode != 0:
            print(f"⚠️  Cleanup completed with warnings")
            if result.stderr:
                print(f"Errors: {result.stderr}")
        
    except Exception as e:
        print(f"⚠️  Workspace root cleanup skipped: {e}")


def placeholder_scan():
    """
    Scan conversation files for placeholders, stubs, and incomplete code
    This is Phase 2.5 - enforces P16 (Accuracy) and P21 (Document Assumptions)
    """
    print("\n" + "="*70)
    print("PHASE 2.5: PLACEHOLDER & STUB DETECTION")
    print("="*70)
    print("\nScanning for incomplete code and placeholders...\n")
    
    scan_script = WORKSPACE / "N5/scripts/n5_placeholder_scan.py"
    
    if not scan_script.exists():
        print("⚠️  Placeholder scan script not found, skipping")
        print(f"   Expected: {scan_script}")
        return True
    
    try:
        # Run placeholder scan
        result = subprocess.run(
            [sys.executable, str(scan_script)],
            capture_output=True,
            text=True,
            check=False,
            timeout=60
        )
        
        # Print scan results
        if result.stdout:
            print(result.stdout)
        
        # Exit code: 0 = clean, 1 = issues found, 2 = error
        if result.returncode == 0:
            print("✓ No placeholders detected - all clear\n")
            return True
        
        elif result.returncode == 1:
            # Issues found - require resolution
            print("\n" + "="*70)
            print("⚠️  RESOLUTION REQUIRED BEFORE CONVERSATION-END")
            print("="*70)
            print("\nYou must address these issues before closing the conversation.")
            print("\nOptions:")
            print("  1. Return to conversation and fix issues")
            print("  2. Document as intentional (add '# DOCUMENTED:' prefix to lines)")
            print("  3. Acknowledge and continue (will be logged for later)")
            
            # Check for auto mode
            if "--auto" in sys.argv or "--yes" in sys.argv:
                print("\n→ Auto mode: Logging issues and continuing...")
                log_action("Placeholder scan: issues detected but auto-acknowledged")
                return True
            
            print("\nHow would you like to proceed?")
            print("  [F]ix now (abort conversation-end)")
            print("  [A]cknowledge & continue (log issues)")
            print("  [Q]uit (abort conversation-end)")
            
            while True:
                response = input("\n> ").strip().lower()
                
                if response in ['f', 'fix']:
                    print("\n❌ Conversation-end aborted - return to fix issues")
                    log_action("Conversation-end aborted: placeholder scan issues")
                    return False
                
                elif response in ['a', 'acknowledge', 'ack']:
                    print("\n→ Issues acknowledged - logging for follow-up")
                    log_action("Placeholder scan: issues acknowledged, continuing")
                    return True
                
                elif response in ['q', 'quit', 'abort']:
                    print("\n❌ Conversation-end aborted by user")
                    return False
                
                else:
                    print("Invalid choice. Please enter F (fix), A (acknowledge), or Q (quit)")
        
        else:
            # Error in scan
            print(f"⚠️  Placeholder scan failed with error code {result.returncode}")
            if result.stderr:
                logger.error(f"Scan error: {result.stderr}")
            print("→ Continuing conversation-end despite scan error")
            return True
        
    except subprocess.TimeoutExpired:
        print("⚠️  Placeholder scan timed out (>60s), continuing...")
        return True
    
    except Exception as e:
        print(f"⚠️  Placeholder scan error: {e}")
        logger.debug("Scan error details", exc_info=True)
        return True


def archive_build_tasks():
    """
    Archive completed tasks from build tracker (Phase 3.5).
    Closes build session and generates archive of completed tasks.
    """
    print("\n" + "="*70)
    print("PHASE 3.5: BUILD TRACKER ARCHIVAL")
    print("="*70)
    print("\nChecking for build tracking data to archive...\n")
    
    # Check if BUILD_MAP exists in conversation workspace
    if not CONVERSATION_WS:
        print("→ No conversation workspace detected, skipping build archival")
        return
    
    build_map = CONVERSATION_WS / "BUILD_MAP.md"
    if not build_map.exists():
        print("→ No BUILD_MAP found, skipping build archival")
        return
    
    # Import build tracker
    try:
        sys.path.insert(0, str(WORKSPACE / "N5/scripts"))
        from build_tracker import BuildTracker
    except ImportError as e:
        print(f"⚠️  Could not import BuildTracker: {e}")
        print("   Skipping build archival")
        return
    
    try:
        # Detect conversation ID
        convo_id = CONVERSATION_WS.name if CONVERSATION_WS else "unknown"
        tracker = BuildTracker(convo_id=convo_id)
        
        # Check if already closed
        if tracker.is_session_closed():
            print(f"✓ Build session already closed for {convo_id}")
            return
        
        # Close session and generate archive
        print(f"Closing build session: {convo_id}")
        
        # First, generate archive of completed tasks
        archive_file = tracker.generate_archive(dry_run=False)
        
        # Then close the session
        summary = tracker.close_session(dry_run=False)
        
        if summary.get("error"):
            print(f"⚠️  {summary['error']}")
            return
        
        # Report results
        print(f"\n✓ Build session closed successfully")
        print(f"  Total tasks: {summary['total']}")
        print(f"  Completed (archived): {summary['complete']}")
        print(f"  Active/Open: {summary['active'] + summary['open']}")
        
        if archive_file:
            print(f"  Archive: {archive_file.name}")
        
        # Refresh BUILD_MAP to show only active tasks
        if tracker.refresh():
            print(f"\n✓ BUILD_MAP updated to hide completed tasks")
        
    except Exception as e:
        print(f"⚠️  Build archival error: {e}")
        logger.debug("Build archival error details", exc_info=True)
        print("→ Continuing with conversation-end...")


def extract_lessons():
    """
    Extract lessons from this conversation (Phase -1)
    This runs before AAR to capture techniques, patterns, and troubleshooting
    """
    print("\n" + "="*70)
    print("PHASE -1: LESSON EXTRACTION")
    print("="*70)
    print("\nAnalyzing conversation for significant lessons...\n")
    
    lessons_script = WORKSPACE / "N5/scripts/n5_lessons_extract.py"
    
    if not lessons_script.exists():
        print("⚠️  Lessons extraction script not found. Skipping Phase -1.")
        print(f"   Expected: {lessons_script}")
        return
    
    try:
        result = subprocess.run(
            [sys.executable, str(lessons_script), "--auto"],
            capture_output=True,
            text=True,
            check=False,
            timeout=180
        )
        if result.stdout:
            print(result.stdout)
        if result.stderr:
            print(result.stderr)
        print("✓ Phase -1 complete (lessons extraction attempted)")
    except Exception as e:
        print(f"⚠️  Lessons extraction error: {e}")
        print("→ Continuing to Phase 0 (AAR)")


def generate_aar():
    """
    Generate After-Action Report (AAR) for this conversation
    This is Phase 0 - captures conversation context before cleanup
    """
    print("\n" + "="*70)
    print("PHASE 0: AFTER-ACTION REPORT (AAR) GENERATION")
    print("="*70)
    print("\nCapturing conversation context and decisions...\n")
    
    aar_script = WORKSPACE / "N5/scripts/n5_thread_export.py"
    
    if not aar_script.exists():
        print("⚠️  AAR script not found, skipping AAR generation")
        print(f"   Expected: {aar_script}")
        return
    
    try:
        # Run AAR export with auto-detect and auto-confirm (--yes flag for non-interactive)
        result = subprocess.run(
            [sys.executable, str(aar_script), "--auto", "--yes"],
            capture_output=True,
            text=True,
            check=False,
            timeout=300  # 5 minute timeout
        )
        
        # Print output
        if result.stdout:
            print(result.stdout)
        if result.stderr:
            print(result.stderr)
        print("✓ Phase 0 complete (AAR generation attempted)")
    except Exception as e:
        print(f"⚠️  AAR generation error: {e}")
        print("→ Continuing with conversation-end...")


def git_status_check():
    """
    Check git status and prompt for commit if there are uncommitted changes
    This is Phase 4 - ensures work is saved before conversation ends
    """
    print("\n" + "="*70)
    print("PHASE 4: GIT STATUS CHECK")
    print("="*70)
    print("\nChecking for uncommitted changes...\n")
    
    try:
        # Check git status
        status_result = subprocess.run(
            ["git", "status", "--short"],
            cwd=str(WORKSPACE),
            capture_output=True,
            text=True,
            check=False
        )
        
        if status_result.returncode != 0:
            print("⚠️  Git status check failed - not a git repository or git error")
            return
        
        changes = status_result.stdout.strip()
        
        if not changes:
            print("✅ No uncommitted changes - git is clean")
            return
        
        # There are changes - show them
        print("📝 Uncommitted changes detected:\n")
        print(changes)
        print()
        
        # Run git-check to audit staged changes
        git_check_script = WORKSPACE / "N5/scripts/n5_git_check.py"
        if git_check_script.exists():
            print("-" * 70)
            print("Running git-check audit...\n")
            audit_result = subprocess.run(
                [sys.executable, str(git_check_script)],
                capture_output=True,
                text=True,
                check=False
            )
            if audit_result.stdout:
                print(audit_result.stdout)
            print("-" * 70)
            print()
        
        # Prompt user to commit
        print("⚠️  You have uncommitted changes.")
        
        # Check for --auto flag (skip prompt in auto mode)
        if "--auto" in sys.argv or "--yes" in sys.argv:
            print("   (Auto mode: skipping commit prompt)")
            return
        
        response = input("Commit changes before ending conversation? (Y/n): ").strip().lower()
        
        if response not in ['y', 'yes', '']:
            print("→ Skipping commit - changes remain uncommitted")
            return
        
        # User wants to commit - get commit message
        print("\nEnter commit message (or press Enter for default):")
        commit_msg = input("> ").strip()
        
        if not commit_msg:
            commit_msg = "conversation-end: save progress"
        
        # Stage all changes
        print("\nStaging all changes...")
        add_result = subprocess.run(
            ["git", "add", "-A"],
            cwd=str(WORKSPACE),
            capture_output=True,
            text=True,
            check=False
        )
        
        if add_result.returncode != 0:
            print(f"❌ Failed to stage changes: {add_result.stderr}")
            return
        
        print("✓ Changes staged")
        
        # Commit
        print(f"Committing with message: '{commit_msg}'...")
        commit_result = subprocess.run(
            ["git", "commit", "-m", commit_msg],
            cwd=str(WORKSPACE),
            capture_output=True,
            text=True,
            check=False
        )
        
        if commit_result.returncode != 0:
            print(f"❌ Commit failed: {commit_result.stderr}")
            return
        
        # Show commit summary
        print("✅ Changes committed successfully\n")
        print(commit_result.stdout)
        
        # Log the commit
        log_action(f"Git commit: {commit_msg}")
        
    except Exception as e:
        print(f"⚠️  Git status check failed: {e}")
        logger.debug("Git check error details", exc_info=True)


def timeline_update_check():
    """
    Check for timeline-worthy changes and auto-write timeline entry
    This is Phase 4.5 - captures system changes in timeline (AUTOMATIC, no prompts)
    """
    print("\n" + "="*70)
    print("PHASE 4.5: SYSTEM TIMELINE AUTO-UPDATE")
    print("="*70)
    print("\nScanning for timeline-worthy changes...\n")
    
    if not TIMELINE_AUTOMATION_AVAILABLE:
        print("  → Timeline automation not available, skipping")
        return
    
    try:
        # Use git status to find recently changed files (more accurate than time-based)
        import subprocess
        
        # Get uncommitted changes
        status_result = subprocess.run(
            ["git", "status", "--short"],
            cwd=str(WORKSPACE),
            capture_output=True,
            text=True,
            check=False
        )
        
        if status_result.returncode != 0:
            print("  → No git repository, using workspace scan")
            # Fallback to workspace-based detection
            from timeline_automation_module import TimelineDetector
            detector = TimelineDetector()
            
            is_worthy, suggested_entry = detector.analyze_file_changes(WORKSPACE)
            
            if not is_worthy:
                print("  → No timeline-worthy changes detected")
                return
            
            # Auto-write (no prompt)
            entry = detector.create_entry(**suggested_entry)
            success = detector.write_entry(entry)
            
            if success:
                print(f"  ✅ Timeline updated: {entry['title']}")
                print(f"     Category: {entry['category']} | Impact: {entry['impact']}")
                print(f"     Entry ID: {entry['entry_id']}")
            return
        
        # Parse git status output for N5-relevant files
        changes = status_result.stdout.strip()
        
        if not changes:
            print("  → No changes detected")
            return
        
        # Scan for high-signal N5 file changes
        new_commands = []
        modified_scripts = []
        
        for line in changes.split('\n'):
            if not line.strip():
                continue
            
            # Format: "XY filename"
            parts = line.split(maxsplit=1)
            if len(parts) < 2:
                continue
            
            status_code = parts[0]
            filepath = parts[1]
            
            # New command files
            if 'N5/commands/' in filepath and filepath.endswith('.md'):
                if status_code.startswith('?') or status_code.startswith('A'):
                    cmd_name = Path(filepath).stem
                    new_commands.append(cmd_name)
            
            # Modified scripts
            if 'N5/scripts/' in filepath and filepath.startswith('n5_') and filepath.endswith('.py'):
                if status_code.startswith('M') or status_code.startswith('A'):
                    modified_scripts.append(Path(filepath).name)
        
        # Determine if timeline-worthy
        has_new_commands = len(new_commands) > 0
        has_multiple_scripts = len(modified_scripts) >= 2
        
        if not (has_new_commands or has_multiple_scripts):
            print("  → No timeline-worthy changes detected")
            return
        
        # Generate entry automatically
        from timeline_automation_module import TimelineDetector
        detector = TimelineDetector()
        
        if has_new_commands:
            title = f"New command(s): {', '.join(new_commands)}"
            description = f"Created {len(new_commands)} new command(s): {', '.join(new_commands)}"
            category = "command"
            components = [f"N5/commands/{cmd}.md" for cmd in new_commands]
            impact = "medium"
            tags = ["automation"]
        else:
            title = "System script updates"
            description = f"Updated {len(modified_scripts)} system scripts: {', '.join(modified_scripts[:3])}"
            category = "infrastructure"
            components = modified_scripts
            impact = "low"
            tags = ["maintenance"]
        
        # Create and write entry (no prompt)
        entry = detector.create_entry(
            title=title,
            description=description,
            category=category,
            components=components,
            impact=impact,
            status='completed',
            tags=tags
        )
        
        success = detector.write_entry(entry)
        
        if success:
            print(f"  ✅ Timeline updated: {entry['title']}")
            print(f"     Category: {entry['category']} | Impact: {entry['impact']}")
            if components:
                print(f"     Components: {len(components)} file(s)")
            print(f"     Entry ID: {entry['entry_id']}")
        
    except Exception as e:
        print(f"  ⚠️  Timeline check skipped: {e}")
        logger.debug(f"Timeline check error details", exc_info=True)


def main():
    """Main execution"""
    
    # Check if we're in a real conversation context
    if not CONVERSATION_WS or not CONVERSATION_WS.exists():
        print("\n" + "="*70)
        print("❌ CONVERSATION WORKSPACE NOT FOUND")
        print("="*70)
        print(f"\nSearched: {CONVERSATION_WS}")
        print("\nThis command organizes files created during the conversation.")
        print("It appears no conversation workspace was detected.")
        print("\nPossible reasons:")
        print("  - Not running in a conversation context")
        print("  - Workspace directory doesn't exist")
        print("  - Environment variable CONVERSATION_WORKSPACE not set")
        return 1
    
    print("\n" + "="*70)
    print("N5 CONVERSATION END-STEP")
    print("="*70)
    print(f"\nConversation workspace: {CONVERSATION_WS}")
    
    # NEW: Phase -1 - Extract lessons
    extract_lessons()
    
    # NEW: Phase 0 - Generate AAR
    generate_aar()
    
    # Step 1: Inventory
    print("\n" + "="*70)
    print("PHASE 1: FILE ORGANIZATION")
    print("="*70)
    print("\nStep 1: Inventorying files...")
    files_by_category = inventory_workspace()
    
    if not any(files_by_category.values()):
        print("\n✓ No files to organize - conversation workspace is clean")
        # Continue to subsequent phases even when no files to organize
        confirmed = True  # Skip to cleanup phases
    else:
        # Step 2: Propose
        proposal = propose_organization(files_by_category)
        print(proposal)
        
        # Step 3: Get confirmation
        if "--auto" in sys.argv or "--yes" in sys.argv:
            confirmed = True
        else:
            response = input("\n> ").strip().lower()
            confirmed = response in ['y', 'yes', '']
    
    # Step 4: Execute (or skip if no files)
    if confirmed:
        if any(files_by_category.values()):
            result = execute_organization(files_by_category, confirmed=True)
            
            # Log conversation end
            log_action(f"Conversation ended: {result['moved']} moved, {result['deleted']} deleted")
        
        # NEW: Phase 2 - Workspace root cleanup
        print("\n" + "="*70)
        print("CONTINUING TO WORKSPACE ROOT CLEANUP...")
        print("="*70)
        cleanup_workspace_root()
        
        # NEW: Phase 2.5 - Placeholder scan
        print("\n" + "="*70)
        print("SCANNING FOR PLACEHOLDERS & STUBS...")
        print("="*70)
        if not placeholder_scan():
            print("\n❌ Conversation-end aborted - return to fix issues")
            return
        
        # Personal intelligence update (autonomous)
        print("\n" + "="*70)
        print("PHASE 3: PERSONAL INTELLIGENCE UPDATE")
        print("="*70)
        try:
            intelligence_script = WORKSPACE / "N5/scripts/update_personal_intelligence.py"
            if intelligence_script.exists():
                logger.info("Updating personal intelligence layer (autonomous)...")
                subprocess.run([sys.executable, str(intelligence_script)], check=False)
            else:
                print("⚠️  Personal intelligence script not found, skipping")
        except Exception as e:
            logger.warning(f"Personal intelligence update skipped: {e}")
        
        # NEW: Phase 3.5 - Build tracker archival
        archive_build_tasks()
        
        # NEW: Phase 4 - Git status check
        git_status_check()
        
        # NEW: Phase 4.5 - Timeline update check
        timeline_update_check()
        
        # Final summary
        print("\n" + "="*70)
        print("✅ CONVERSATION END-STEP COMPLETE")
        print("="*70)
    else:
        print("\n✓ Organization cancelled - files remain in conversation workspace")


if __name__ == "__main__":
    main()
