#!/usr/bin/env python3
"""
Demo for Priority 3: Meeting Monitor
Demonstrates monitoring loop with mock data.
"""

import sys
from pathlib import Path
from datetime import datetime, timedelta
import pytz

# Add N5/scripts to path
script_dir = Path(__file__).parent
sys.path.insert(0, str(script_dir))

from meeting_monitor import MeetingMonitor
from digest_integration import DigestFormatter


def create_mock_calendar_tool():
    """Create a mock calendar tool that returns sample events."""
    def mock_calendar(tool_name, configured_props):
        # Simulate calendar API response
        et_tz = pytz.timezone('America/New_York')
        now = datetime.now(et_tz)
        
        return {
            'items': [
                {
                    'id': 'event_urgent_1',
                    'summary': 'Series A Discussion - Jane Smith (Acme Ventures)',
                    'description': '[LD-INV] [D5+] *\n\nPurpose: Discuss Series A funding timeline\n\nContext: Jane expressed strong interest after intro.',
                    'start': {'dateTime': (now + timedelta(days=3)).isoformat()},
                    'attendees': [
                        {'email': 'va@zo.computer'},
                        {'email': 'jane@acmeventures.com'}
                    ]
                },
                {
                    'id': 'event_normal_1',
                    'summary': 'Engineering Interview - Alex Chen',
                    'description': '[LD-HIR] [D3]\n\nPurpose: Technical interview for senior role\n\nContext: Strong referral from Mike.',
                    'start': {'dateTime': (now + timedelta(days=4)).isoformat()},
                    'attendees': [
                        {'email': 'va@zo.computer'},
                        {'email': 'alex@engineer.io'}
                    ]
                }
            ]
        }
    
    return mock_calendar


def create_mock_gmail_tool():
    """Create a mock Gmail tool that returns sample email threads."""
    def mock_gmail(tool_name, configured_props):
        email = configured_props.get('query', '').replace('from:', '').strip()
        
        # Return mock thread summary
        return {
            'threads': [
                {
                    'id': 'thread1',
                    'snippet': f'Email exchange with {email}...',
                    'messages': [
                        {
                            'id': 'msg1',
                            'subject': 'Introduction',
                            'date': '2024-10-10',
                            'from': email
                        }
                    ]
                }
            ]
        }
    
    return mock_gmail


def run_demo():
    """Run Priority 3 demo."""
    print("=" * 60)
    print("Priority 3 Demo: Meeting Monitor")
    print("=" * 60)
    print()
    
    # Create mock API tools
    mock_calendar = create_mock_calendar_tool()
    mock_gmail = create_mock_gmail_tool()
    
    # Create monitor
    print("1. Initializing Meeting Monitor...")
    monitor = MeetingMonitor(
        calendar_tool=mock_calendar,
        gmail_tool=mock_gmail,
        poll_interval_minutes=15,
        lookahead_days=7
    )
    print("   ✓ Monitor initialized")
    print()
    
    # Run single cycle
    print("2. Running single monitoring cycle...")
    print()
    result = monitor.run_single_cycle()
    print()
    
    # Display results
    print("3. Cycle Results:")
    print(f"   - Total events checked: {result.get('total_events', 0)}")
    print(f"   - New events processed: {result.get('new_events', 0)}")
    print(f"   - Already processed: {result.get('already_processed', 0)}")
    print(f"   - Urgent meetings: {result.get('urgent_count', 0)}")
    print(f"   - Errors: {result.get('errors', 0)}")
    print()
    
    # Show urgent meetings
    if result.get('urgent_count', 0) > 0:
        print("4. Urgent Meetings Detected:")
        for meeting in result.get('urgent_meetings', []):
            print(f"   🚨 {meeting['summary']}")
            print(f"      Time: {meeting['start_time']}")
            print(f"      Attendee: {meeting['attendee_email']}")
        print()
    
    # Show digest section
    if 'digest_section' in result:
        print("5. Digest Section Generated:")
        print()
        print(result['digest_section'])
        print()
    
    # Test digest formatter
    print("6. Testing Digest Formatter...")
    formatter = DigestFormatter()
    
    # Test with multiple cycles
    all_results = [result]  # In real use, this would be multiple cycles
    daily_summary = formatter.format_daily_summary(all_results)
    
    print("   ✓ Daily summary generated")
    print()
    print("7. Daily Summary Example:")
    print()
    print(daily_summary)
    print()
    
    # Summary
    print("=" * 60)
    print("Demo Complete!")
    print("=" * 60)
    print()
    print("What we demonstrated:")
    print("  ✓ Monitor initialization")
    print("  ✓ Single cycle execution")
    print("  ✓ Urgent meeting detection")
    print("  ✓ Digest section generation")
    print("  ✓ Daily summary formatting")
    print()
    print("Next steps:")
    print("  • Test with real Google Calendar API")
    print("  • Run continuous monitoring loop")
    print("  • Integrate with actual digest system")
    print("  • Deploy for production (Priority 4)")
    print()


if __name__ == '__main__':
    run_demo()
