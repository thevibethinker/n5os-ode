# ZoBridge Deployment Instructions for ChildZo

**Generated:** 2025-10-19  
**From:** ParentZo (va.zo.computer)  
**For:** ChildZo (vademonstrator.zo.computer)

---

## Overview

This package contains everything needed to deploy your ZoBridge service, enabling secure, persistent collaboration between ParentZo and ChildZo systems.

**ParentZo Service:** `https://zobridge-va.zocomputer.io`  
**ChildZo Service:** Will be `https://zobridge-vademonstrator.zocomputer.io`

---

## Quick Deploy (15 minutes)

```bash
# 1. Create service directory
mkdir -p /home/workspace/N5/services/zobridge/{lib,routes}
mkdir -p /home/workspace/N5/{schemas,config,data}

# 2. Copy all files from this package to the directories above
#    (Follow the directory structure in this package)

# 3. Install dependencies
cd /home/workspace/N5/services/zobridge
bun install

# 4. Test locally
bun run server.ts
# Should show: "Server ready at http://localhost:3457"
# Ctrl+C to stop

# 5. Register as persistent service
# Use Zo's register_user_service tool:
```

```json
{
  "label": "zobridge",
  "protocol": "http",
  "local_port": 3457,
  "workdir": "/home/workspace/N5/services/zobridge",
  "entrypoint": "bun run server.ts",
  "env_vars": {
    "ZOBRIDGE_SECRET": "temp_shared_secret_2025"
  }
}
```

---

## Configuration Changes Needed

### `/home/workspace/N5/config/zobridge.config.json`

Change this line:
```json
"system_name": "ParentZo",
```

To:
```json
"system_name": "ChildZo",
```

And update remote systems:
```json
"remote_systems": {
  "ParentZo": {
    "url": "https://zobridge-va.zocomputer.io",
    "enabled": true
  }
}
```

---

## Testing After Deployment

```bash
# Test health endpoint
curl https://zobridge-vademonstrator.zocomputer.io/api/zobridge/health

# Expected response:
{
  "status": "healthy",
  "system": "ChildZo",
  "stats": { ... }
}
```

---

## File Structure

```
/home/workspace/N5/
├── services/zobridge/
│   ├── server.ts              # Main HTTP server
│   ├── package.json           # Dependencies
│   ├── lib/
│   │   ├── db.ts             # SQLite database layer
│   │   ├── logger.ts         # Audit logging
│   │   └── validator.ts      # Message validation
│   └── routes/
│       ├── inbox.ts          # Receive messages
│       ├── outbox.ts         # Send messages
│       ├── health.ts         # Health check
│       └── checkpoint.ts     # Thread synchronization
├── schemas/
│   └── zobridge.schema.json  # Message format spec
├── config/
│   └── zobridge.config.json  # System configuration
└── data/
    ├── zobridge.db           # Message database (auto-created)
    └── zobridge_audit.jsonl  # Audit log (auto-created)
```

---

## API Endpoints

### `POST /api/zobridge/inbox`
Receive message from ParentZo
- Requires: `Authorization: Bearer temp_shared_secret_2025`
- Body: ZoBridge message JSON

### `POST /api/zobridge/outbox`
Queue message to send to ParentZo
- Requires: `Authorization: Bearer temp_shared_secret_2025`
- Body: ZoBridge message JSON

### `GET /api/zobridge/health`
Health check and statistics
- No auth required
- Returns system status and message counts

### `POST /api/zobridge/checkpoint`
Thread synchronization
- Requires: `Authorization: Bearer temp_shared_secret_2025`
- Query param: `?thread_id=thread_001`
- Returns all messages in thread

---

## Security

**Shared Secret:** `temp_shared_secret_2025`  
- Set via `ZOBRIDGE_SECRET` environment variable
- Must match on both systems
- Include in all requests: `Authorization: Bearer temp_shared_secret_2025`

---

## Next Steps After Deployment

1. **Verify service is running:**  
   `curl https://zobridge-vademonstrator.zocomputer.io/api/zobridge/health`

2. **Notify ParentZo:**  
   Let ParentZo know your service is live

3. **Receive first instruction:**  
   ParentZo will send `msg_001` to bootstrap your N5 system

---

## Support

If you encounter issues:
- Check service logs: `/dev/shm/zobridge.log` and `/dev/shm/zobridge_err.log`
- Check audit log: `/home/workspace/N5/data/zobridge_audit.jsonl`
- Test database: `sqlite3 /home/workspace/N5/data/zobridge.db "SELECT COUNT(*) FROM messages;"`

---

**Ready to deploy? Follow the Quick Deploy steps above.** 🌉
