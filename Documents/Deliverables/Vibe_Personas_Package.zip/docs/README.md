# Vibe Personas Package

This package contains the **Vibe Persona System**, a comprehensive set of 10 specialized AI personas designed to work together as a cohesive team.

## Overview

The Vibe system operates on a "Generalist -> Specialist" model. 
- **Vibe Operator** is your home base (generalist).
- When you have a specific task (coding, writing, strategy), the Operator routes you to a **Specialist**.
- **Vibe Level Upper** acts as a manager for complex, multi-step tasks.

## The Personas

1. **Vibe Operator**: Execution, navigation, and routing. Home base.
2. **Vibe Strategist**: Decision making, frameworks, tradeoffs.
3. **Vibe Builder**: Implementation, coding, systems.
4. **Vibe Writer**: Polished communication and content.
5. **Vibe Teacher**: Explaining complex concepts.
6. **Vibe Researcher**: Deep dive information gathering.
7. **Vibe Debugger**: QA, verification, fixing broken things.
8. **Vibe Architect**: Meta-design (system/persona architecture).
9. **Vibe Level Upper**: Reasoning enhancement and orchestration.
10. **Vibe Coach**: Reflection and emotional processing.

## Installation

1. **Import Personas**:
   - Create these 10 personas in your AI settings.
   - Copy the prompts from the `personas/` folder.
   - **CRITICAL STEP**: When you create each persona, the system will generate a unique ID (e.g., `567cc602-060b...`). 
   - You MUST replace the placeholder IDs in the prompt text (e.g., `INSERT_BUILDER_ID`) with the actual ID you just generated. 
   - *Tip*: Create all personas first, note their IDs, then go back and update the `set_active_persona("...")` calls in the prompts.

2. **Configure Rules**:
   - Go to `system/REQUIRED_RULES.md`.
   - Copy these rules into your "User Rules" section.
   - *Crucial*: These rules enable the "Auto-Routing" behavior.

3. **Update IDs (Optional but Recommended)**:
   - If you want to use the `persona_router.py` script, update the `PERSONA_IDS` dictionary in `system/persona_router.py` with your actual persona IDs.

## Usage

Once installed, simply chat with your AI (Operator).
- "Help me build a python script" -> Should auto-route to **Builder**.
- "I need to make a strategic decision" -> Should auto-route to **Strategist**.
- "Draft a blog post" -> Should auto-route to **Writer**.

The system is designed to be **proactive**. It shouldn't ask "Should I switch to Builder?"; it should just say "Routing to Builder..." and do it.
