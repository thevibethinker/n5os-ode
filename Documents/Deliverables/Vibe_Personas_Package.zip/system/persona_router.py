#!/usr/bin/env python3
"""
Persona Auto-Routing System (Export Version)
Analyzes user messages and routes to appropriate persona based on keyword/regex triggers.
"""

import sys
import re
from typing import Dict, List, Optional

# Define your Persona IDs here - REPLACE THESE WITH YOUR ACTUAL IDs
PERSONA_IDS = {
    "operator": "INSERT_OPERATOR_ID",
    "strategist": "INSERT_STRATEGIST_ID",
    "researcher": "INSERT_RESEARCHER_ID",
    "teacher": "INSERT_TEACHER_ID",
    "builder": "INSERT_BUILDER_ID",
    "architect": "INSERT_ARCHITECT_ID",
    "writer": "INSERT_WRITER_ID",
    "debugger": "INSERT_DEBUGGER_ID",
    "level_upper": "INSERT_LEVEL_UPPER_ID",
    "coach": "INSERT_COACH_ID"
}

PERSONAS = {
    "operator": {
        "name": "Vibe Operator",
        "triggers": [r"move|copy|delete|organize", r"run.*script", r"execute", r"navigate"],
        "default": True
    },
    "strategist": {
        "name": "Vibe Strategist",
        "triggers": [r"strategy|strategic", r"decide|decision", r"roadmap", r"tradeoff"],
        "default": False
    },
    "researcher": {
        "name": "Vibe Researcher",
        "triggers": [r"research", r"find|search", r"investigate", r"gather info"],
        "default": False
    },
    "teacher": {
        "name": "Vibe Teacher",
        "triggers": [r"explain", r"teach me", r"how does.*work", r"understand"],
        "default": False
    },
    "builder": {
        "name": "Vibe Builder",
        "triggers": [r"build", r"create.*script", r"implement", r"code"],
        "default": False
    },
    "architect": {
        "name": "Vibe Architect",
        "triggers": [r"design.*system", r"architect", r"blueprint", r"create persona"],
        "default": False
    },
    "writer": {
        "name": "Vibe Writer",
        "triggers": [r"write.*article", r"draft", r"compose", r"blog post"],
        "default": False
    },
    "debugger": {
        "name": "Vibe Debugger",
        "triggers": [r"debug", r"fix", r"broken", r"error", r"not working"],
        "default": False
    },
    "level_upper": {
        "name": "Vibe Level Upper",
        "triggers": [r"major build", r"critical", r"complex reasoning"],
        "default": False
    },
    "coach": {
        "name": "Vibe Coach",
        "triggers": [r"reflect", r"journal", r"feeling", r"process"],
        "default": False
    }
}

class PersonaRouter:
    def __init__(self):
        self.personas = PERSONAS
    
    def analyze(self, message: str):
        message_lower = message.lower()
        scores = {}
        
        for key, persona in self.personas.items():
            if persona["default"]: continue
            
            score = 0
            for trigger in persona["triggers"]:
                if re.search(trigger, message_lower):
                    score += 1
            
            if score > 0:
                scores[key] = score
        
        if not scores:
            return "operator", self.personas["operator"]["name"]
        
        best_key = max(scores, key=scores.get)
        return best_key, self.personas[best_key]["name"]

def main():
    if len(sys.argv) < 2:
        print("Usage: python3 persona_router.py 'message'")
        sys.exit(1)
        
    router = PersonaRouter()
    key, name = router.analyze(sys.argv[1])
    
    print(f"Recommended Persona: {name}")
    print(f"ID: {PERSONA_IDS.get(key, 'UNKNOWN')}")

if __name__ == "__main__":
    main()
