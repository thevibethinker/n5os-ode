# Vibe Personas System

A suite of 10 specialized AI personas that automatically route tasks to the best expert.

## Installation

1.  **Unzip** this package to your Zo workspace (e.g., in `Documents/Vibe`).
2.  **Open** the chat.
3.  **Run** the setup prompt by typing:
    `@Documents/Vibe/setup_vibe.prompt.md`
    (or wherever you saved it).
4.  **Follow** the agent's instructions. It will:
    - Create all personas.
    - "Wire" them together (replacing placeholders with real IDs).
    - Give you a block of **Rules** to copy into your settings.

## The Personas

- **Operator**: The quarterback. Handles navigation and simple tasks. Routes everything else.
- **Strategist**: Decisions, frameworks, pattern matching.
- **Builder**: Code, scripts, implementation.
- **Teacher**: Concepts, mental models, explanations.
- **Writer**: Content, docs, emails.
- **Debugger**: Fixes, QA, validation.
- **Architect**: System design, meta-design.
- **Researcher**: Deep dives, fact checking.
- **Level Upper**: "System 2" thinking for complex tasks.
- **Coach**: Reflection and growth.

## Troubleshooting

If switching feels "suboptimal" (e.g., staying on Operator too long):
- Check your **User Rules**. Ensure the routing rule is present and has the correct IDs.
- Explicitly ask: "Route this to [Persona Name]" to force a switch and see if it sticks.
